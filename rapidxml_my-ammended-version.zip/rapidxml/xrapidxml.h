#ifndef BUFFSZ
#define BUFFSZ 20000
#endif

#ifndef BUFFFACTOR
#define BUFFFACTOR 1.2
#endif

#define TEST_XRAPIDXML


#include <fstream>
#include <iostream>
#include <new>

#include "rapidxml-1.13/rapidxml.hpp"
#include "rapidxml-1.13/rapidxml_iterators.hpp"
#include "rapidxml-1.13/rapidxml_print.hpp"
#include "rapidxml-1.13/rapidxml_utils.hpp"

const char closed_file_exception_string[] = "file is not open!!!";

template <typename CHAR = char>
class xrapidxml : public rapidxml::xml_document<CHAR> {
public:
  typedef rapidxml::xml_document<CHAR> base_type;
  using base_type::parse;
  bool buf_in_use;
  std::size_t buflen;
  char *      buf;   // 'buf' holds 'buflen' characters plus one, so that buf[buflen] == '\0'
  float  buf_factor; // at least 1.0

  void parse(std::ifstream& infile) {
    // check that file is opened:
    if(!infile.is_open())
      throw rapidxml::parse_error(closed_file_exception_string,0);
    // check that buf_factor >= 1
    if(buf_factor < 1)
      throw std::exception();
    // compute size of buffer
    std::size_t len;
    infile.seekg(0, std::ios_base::end);    // go to the end
    len = infile.tellg();           // report location (this is the length)
    // get a chunk of contiguous memory to hold the contents of infile
    if(len > buflen) {
      buflen = static_cast<std::size_t>(len * buf_factor);
      if(buflen < BUFFSZ)
        buflen = BUFFSZ;
      buf = new char[buflen + 1]; // reserve one more char so that it can be made 0 terminated
      if(buf == 0) // should allocation fail...
        throw std::bad_alloc();
    }
#ifdef TEST_XRAPIDXML
      std::cout << "len=" << len << ", buflen=" << buflen << ", BUFFFACTOR=" << BUFFFACTOR << ", and buf is size " << buflen + 1<< " (chars)" << std::endl;
#endif
    // read the whole file into the buffer and make the last char a \  0
    infile.seekg(0);    // go static_cast<std::size_t>back to the beginning
    infile.read(buf, len);
    buf[len] = '\0';
    buf_in_use = true;
    // Now do parse()
    parse<0>(buf);
  }; // end of function 'void parse(std::ifstream& infile)'
  //
  std::ifstream inf;
  bool inf_open;
  // constructors and destructor:
  xrapidxml(                       float f = BUFFFACTOR) : buf_in_use(false), buflen(0), buf_factor(f), inf_open(false) {};
  xrapidxml(std::ifstream& infile, float f = BUFFFACTOR) :                    buflen(0), buf_factor(f), inf_open(false) {
    parse(infile);
  };
  xrapidxml(const char * filename, float f = BUFFFACTOR) :                    buflen(0), buf_factor(f), inf_open( true) {
    inf.open(filename, std::ifstream::binary);
    parse(inf);
  };
  ~xrapidxml() {
    if(buf_in_use)
      delete buf;
    if(inf_open)
      inf.close();
  };
};
