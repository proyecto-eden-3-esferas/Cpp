var searchData=
[
  ['last_5fattribute_17',['last_attribute',['../classrapidxml_1_1xml__node.html#a67db03d1568dc6891573210ddba61520',1,'rapidxml::xml_node']]],
  ['last_5fnode_18',['last_node',['../classrapidxml_1_1xml__node.html#a524d427e32c72fba9de1857e02e82fa7',1,'rapidxml::xml_node']]]
];
