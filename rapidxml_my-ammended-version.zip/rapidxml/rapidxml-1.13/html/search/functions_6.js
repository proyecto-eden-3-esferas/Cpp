var searchData=
[
  ['memory_5fpool_127',['memory_pool',['../classrapidxml_1_1memory__pool.html#a0b609da81dff28a19ebd704400788429',1,'rapidxml::memory_pool']]]
];
