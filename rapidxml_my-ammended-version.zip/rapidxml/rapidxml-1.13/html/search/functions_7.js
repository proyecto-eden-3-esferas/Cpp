var searchData=
[
  ['name_128',['name',['../classrapidxml_1_1xml__base.html#aef8ae147fbee59209f714274afc80dc4',1,'rapidxml::xml_base::name() const'],['../classrapidxml_1_1xml__base.html#ae55060ae958c6e6465d6c8db852ec6ce',1,'rapidxml::xml_base::name(const Ch *name, std::size_t size)'],['../classrapidxml_1_1xml__base.html#a4611ddc82ac83a527c65606600eb2a0d',1,'rapidxml::xml_base::name(const Ch *name)']]],
  ['name_5fsize_129',['name_size',['../classrapidxml_1_1xml__base.html#a20c8ffbe0c7a0b4231681ab8b99330a4',1,'rapidxml::xml_base']]],
  ['next_5fattribute_130',['next_attribute',['../classrapidxml_1_1xml__attribute.html#affd0c8d0a9020df0998c507cae5474e5',1,'rapidxml::xml_attribute']]],
  ['next_5fsibling_131',['next_sibling',['../classrapidxml_1_1xml__node.html#ad36aa4445ced578f93c3e06770cb3ef9',1,'rapidxml::xml_node']]]
];
