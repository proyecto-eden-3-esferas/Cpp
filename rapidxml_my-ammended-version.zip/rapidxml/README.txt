CLASS HIERARCHY

xml_base    is one       base of xml_document
memory_pool is the other base of xml_document

NOTE:
- A utility function for reading or loading a whole file into a string
  is found in file "read-file-into-string.cpp"

MENDING SOURCE CODE:

- If file rapidxml_iterators.hpp I had to rewrite
    typedef typename xml_attribute<Ch> value_type;
  to
    typedef xml_attribute<Ch> value_type;
  and generally I had to remove several instances of typname,
  which were otherwise perfectly unnecessary.

- In rapidxml_print.hpp I had to introduce some forward declarations of functions
  in line 105, preceded by a comment ("// Some FORWARD DECLARATIONS:")

TODOs:

- Clarify how holding a string by reference or by value works in the rapidxml library

- Define a class whose constructor takes an in file reference.
  It should be a subclass of rapidxml::xml_document...
  It is currently being developed in xrapidxml.h and tested in xrapidxml.cpp

- Code some allocator scheme for getting and releasing large buffers.

- Remove "using namespace rapidxml;" from your test files.

- Define a xrapidxml constructor that takes a file path as its argument.


FLAGS
I think flags are poorly documented. I shall discuss some here:
- parse_no_utf8 -> prevents numeric character reference being expanded into appropriate UTF-8 byte sequences
- node_element  -> the kind of node is an XML element node, as in doc.allocate_node(node_element, "firstterm", "algorithmic")
- parse_non_destructive -> strings in the source text will not be zero terminated,
  so you'll need to use xml_base::name_size() and xml_base::value_size()
- enum node_type holds: node_document, node_element, node_data, node_cdata, node_comment, node_declaration, node_doctype, and node_pi
- parse constants: parse_no_data_nodes, parse_no_element_values, parse_no_string_terminators, parse_no_entity_translation, parse_no_utf8, parse_declaration_node, parse_comment_nodes, parse_doctype_node, parse_pi_nodes, parse_validate_closing_tags, parse_trim_whitespace, parse_normalize_whitespace, parse_default, parse_non_destructive, parse_fastest, parse_full, and print_no_indenting


CLASS rapidxml::memory_pool
Pool maintains RAPIDXML_STATIC_POOL_SIZE bytes of statically allocated memory. Until static memory is exhausted, no dynamic memory allocations are done. When static memory is exhausted, pool allocates additional blocks of memory of size RAPIDXML_DYNAMIC_POOL_SIZE each, by using global new[] and delete[] operators. This behaviour can be changed by setting custom allocation routines. Use set_allocator() function to set them.
