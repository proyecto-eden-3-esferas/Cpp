var searchData=
[
  ['memory_5fpool_19',['memory_pool',['../classrapidxml_1_1memory__pool.html#a0b609da81dff28a19ebd704400788429',1,'rapidxml::memory_pool::memory_pool()'],['../classrapidxml_1_1memory__pool.html',1,'rapidxml::memory_pool&lt; Ch &gt;']]],
  ['memory_5fpool_3c_20char_20_3e_20',['memory_pool&lt; char &gt;',['../classrapidxml_1_1memory__pool.html',1,'rapidxml']]]
];
