#include <iostream>
#include <string>
#include "rapidxml-1.13/rapidxml.hpp"

namespace rx = rapidxml;
using namespace std;


int main() {

  rx::xml_document<> doc;    // character type defaults to char

  char text[] = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
<book author=\"anonymous\" xml:date=\"2023-09-04\">\
  <chapter n='1'>CHAPTER1</chapter>\
  In between first and second chapter\
  <chapter n='2'>CHAPTER2</chapter>\
</book>";
  doc.parse<0>(text);                      // 0 means default parse flags
  //doc.parse<rx::parse_no_utf8>(text);    // this flag here does nothing

  rx::xml_node<> *node = doc.first_node();
  std::string name0(node->name());
  cout << "Name of my first node is: " << name0 << "\n";

  std::cout << "Node named \'" << name0 << "\' has value = \"" << node->value() << "\"\n";

  for (rx::xml_attribute<> *attr = node->first_attribute();
       attr;
       attr = attr->next_attribute())
  {
    std::cout << "Node \'" << name0 << "\' has attribute " << attr->name() << "=\'" << attr->value() << "\'\n";
  }

  node = node->first_node();
  cout << "Name of my first node\'s first node is: " << node->name() << "\n";
  cout << "Value of my first node\'s first node is: " << node->value() << "\n";

  return 0;
}
