var searchData=
[
  ['set_5fallocator_149',['set_allocator',['../classrapidxml_1_1memory__pool.html#a84d3d8d2cdfc00501e1dcf26d889ae03',1,'rapidxml::memory_pool']]],
  ['size_150',['size',['../classrapidxml_1_1file.html#aacd451b3def3ad056fe8342dccee35cd',1,'rapidxml::file']]]
];
