var searchData=
[
  ['insert_5fattribute_123',['insert_attribute',['../classrapidxml_1_1xml__node.html#a9fe659cdf4a5b3bbf5e8ffc98db5a84f',1,'rapidxml::xml_node']]],
  ['insert_5fnode_124',['insert_node',['../classrapidxml_1_1xml__node.html#a666880f42a7e486d78cc45ed51c7c46d',1,'rapidxml::xml_node']]]
];
