var searchData=
[
  ['memory_5fpool_92',['memory_pool',['../classrapidxml_1_1memory__pool.html',1,'rapidxml']]],
  ['memory_5fpool_3c_20char_20_3e_93',['memory_pool&lt; char &gt;',['../classrapidxml_1_1memory__pool.html',1,'rapidxml']]]
];
