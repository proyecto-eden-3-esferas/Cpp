#include "xrapidxml.h"
using namespace std;

int main(int argc, char * argv[]) {

  ifstream infile;
  if(argc > 1)
    infile.open(argv[1]);
  else {
    infile.open("../../../html/HTML_colors.html");
    cout << "opening \"HTML_colors.html\"..." << endl;
  }

  xrapidxml xr1(infile);
  xrapidxml xr2("../../../html/HTML_colors.html");

  infile.close();

  return 0;
}
