#include <iostream>
#include <string>
#include "rapidxml-1.13/rapidxml.hpp"

namespace rx = rapidxml;
using namespace std;


int main() {

  rx::xml_document<> doc;    // character type defaults to char

  char text[] = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
<book author=\"anonymous\" xml:date=\"2023-09-04\">A book...\
  <chapter>...</chapter>\
</book>";

  rx::xml_node<> *node = doc.allocate_node(rx::node_element, "a", "Google");
  doc.append_node(node);
  rx::xml_attribute<> *attr = doc.allocate_attribute("href", "google.com");
  node->append_attribute(attr);

  std::string name0(doc.first_node()->name());

  cout << "Name of my first node is: " << name0 << "\n";

  node = doc.first_node();
  std::cout << "Node \'" << name0 << "\' has value = \"" << node->value() << "\"\n";

  for (rx::xml_attribute<> *attr = node->first_attribute();
       attr;
       attr = attr->next_attribute())
  {
    std::cout << "Node \'" << name0 << "\' has attribute " << attr->name() << "=\'" << attr->value() << "\'\n";
  }

  return 0;
}
