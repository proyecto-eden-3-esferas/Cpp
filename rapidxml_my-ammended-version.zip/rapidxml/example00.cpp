#include <iostream>
#include <string>

#include "rapidxml-1.13/rapidxml.hpp"
#include "rapidxml-1.13/rapidxml_iterators.hpp"
#include "rapidxml-1.13/rapidxml_print.hpp"
#include "rapidxml-1.13/rapidxml_utils.hpp"

using namespace rapidxml;
using namespace std;


int main() {

  xml_document<> doc;    // character type defaults to char

  char text[] = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
<book author=\"anonymous\" xml:date=\"2023-09-04\">A book...\
  <chapter>...</chapter>\
</book>";

  doc.parse<0>(text);    // 0 means default parse flags

  /*
  std::string name0(doc.first_node()->name());

  cout << "Name of my first node is: " << name0 << "\n";
  xml_node<> *node = doc.first_node();

  std::cout << "Node \'" << name0 << "\' has value = \"" << node->value() << "\"\n";

  for (xml_attribute<> *attr = node->first_attribute();
       attr;
       attr = attr->next_attribute())
  {
    std::cout << "Node \'" << name0 << "\' has attribute " << attr->name() << "=\'" << attr->value() << "\'\n";
  }
  */



  std::cout << "Now print the whole DOM tree using operator \'<<\':" << std::endl;
  std::cout << doc;

  std::cout << "Next, print the whole DOM tree using \'print\':" << std::endl;
  print(std::cout, doc, 0);   // 0 means default printing flags

  //return 0;

  std::cout << "Third, print the whole DOM tree using an output iterator on a string \'s\':" << std::endl;
  std::string s;
  print(std::back_inserter(s), doc, 0);
  std::cout << s << std::endl;

  //return 0;

  std::cout << "Third, print the whole DOM tree to memory buffer using an output iterator:" << std::endl;
  char buffer[4096];                      // You are responsible for making the buffer large enough!
  char *end = print(buffer, doc, 0);      // end contains pointer to character after last printed character
  *end = 0;                               // Add string terminator after XML

  return 0;
}
